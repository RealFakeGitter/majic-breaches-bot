# Majic Breaches Android App

A React Native Android app for Majic Breaches search functionality.

## Prerequisites

- Node.js 18+
- React Native CLI
- Android Studio
- Java Development Kit (JDK) 11+

## Setup

1. Install React Native CLI globally:
   ```bash
   npm install -g @react-native-community/cli
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and fill in your Convex URL:
   ```
   CONVEX_URL=your_convex_deployment_url_here
   ```

4. Start Metro bundler:
   ```bash
   npm start
   ```

5. Run on Android device/emulator:
   ```bash
   npm run android
   ```

## Building APK

1. Generate a signed APK:
   ```bash
   cd android
   ./gradlew assembleRelease
   ```

2. The APK will be generated at:
   ```
   android/app/build/outputs/apk/release/app-release.apk
   ```

## Features

- Search across data breaches
- View detailed breach results
- Search history
- Material Design UI
- Offline capability for viewing previous searches
