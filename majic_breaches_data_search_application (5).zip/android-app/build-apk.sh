#!/bin/bash

echo "🔨 Building Majic Breaches Android APK..."

# Navigate to android directory
cd android

# Make gradlew executable
chmod +x gradlew

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Build release APK
echo "📱 Building release APK..."
./gradlew assembleRelease

# Check if build was successful
if [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
    echo "✅ APK built successfully!"
    echo "📍 APK location: android/app/build/outputs/apk/release/app-release.apk"
    
    # Get APK size
    APK_SIZE=$(du -h app/build/outputs/apk/release/app-release.apk | cut -f1)
    echo "📦 APK size: $APK_SIZE"
    
    # Copy APK to root directory for easy access
    cp app/build/outputs/apk/release/app-release.apk ../majic-breaches-app.apk
    echo "📋 APK copied to: majic-breaches-app.apk"
else
    echo "❌ APK build failed!"
    exit 1
fi
