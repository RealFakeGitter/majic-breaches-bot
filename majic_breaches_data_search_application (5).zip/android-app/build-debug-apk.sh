#!/bin/bash

echo "🔨 Building Majic Breaches Android Debug APK..."

# Navigate to android directory
cd android

# Make gradlew executable
chmod +x gradlew

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Build debug APK
echo "📱 Building debug APK..."
./gradlew assembleDebug

# Check if build was successful
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "✅ Debug APK built successfully!"
    echo "📍 APK location: android/app/build/outputs/apk/debug/app-debug.apk"
    
    # Get APK size
    APK_SIZE=$(du -h app/build/outputs/apk/debug/app-debug.apk | cut -f1)
    echo "📦 APK size: $APK_SIZE"
    
    # Copy APK to root directory for easy access
    cp app/build/outputs/apk/debug/app-debug.apk ../majic-breaches-app-debug.apk
    echo "📋 Debug APK copied to: majic-breaches-app-debug.apk"
else
    echo "❌ Debug APK build failed!"
    exit 1
fi
