import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ConvexHttpClient } from 'convex/browser';
import { CONVEX_URL } from '@env';

interface SearchResult {
  _id: string;
  breachName: string;
  breachDescription?: string;
  content: string;
  matchedField: string;
  dataTypes: string[];
}

interface Search {
  _id: string;
  query: string;
  timestamp: number;
  resultCount: number;
}

const convex = new ConvexHttpClient(CONVEX_URL);

const App = (): JSX.Element => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [currentSearch, setCurrentSearch] = useState<Search | null>(null);
  const [searchHistory, setSearchHistory] = useState<Search[]>([]);
  const [activeTab, setActiveTab] = useState<'search' | 'history'>('search');

  useEffect(() => {
    loadSearchHistory();
  }, []);

  const loadSearchHistory = async () => {
    try {
      const history = await AsyncStorage.getItem('searchHistory');
      if (history) {
        setSearchHistory(JSON.parse(history));
      }
    } catch (error) {
      console.error('Error loading search history:', error);
    }
  };

  const saveSearchToHistory = async (search: Search) => {
    try {
      const updatedHistory = [search, ...searchHistory.slice(0, 19)]; // Keep last 20 searches
      setSearchHistory(updatedHistory);
      await AsyncStorage.setItem('searchHistory', JSON.stringify(updatedHistory));
    } catch (error) {
      console.error('Error saving search history:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      Alert.alert('Error', 'Please enter a search query');
      return;
    }

    setIsSearching(true);
    setSearchResults([]);
    setCurrentSearch(null);

    try {
      // Call Convex action to search breaches
      const result = await convex.action('breaches:searchBreaches', {
        query: searchQuery.trim(),
        limit: 100,
      });

      // Get the search results
      const searchData = await convex.query('breaches:getSearchResults', {
        searchId: result.searchId,
      });

      if (searchData) {
        setCurrentSearch(searchData.search);
        setSearchResults(searchData.results);
        
        // Save to history
        await saveSearchToHistory({
          _id: result.searchId,
          query: searchQuery.trim(),
          timestamp: Date.now(),
          resultCount: result.resultCount,
        });
      }

      Alert.alert('Success', `Found ${result.resultCount} results`);
    } catch (error) {
      Alert.alert('Error', `Search failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsSearching(false);
    }
  };

  const loadHistorySearch = async (search: Search) => {
    setActiveTab('search');
    setCurrentSearch(search);
    setSearchQuery(search.query);
    
    try {
      const searchData = await convex.query('breaches:getSearchResults', {
        searchId: search._id,
      });
      
      if (searchData) {
        setSearchResults(searchData.results);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to load search results');
    }
  };

  const renderSearchResult = ({ item }: { item: SearchResult }) => (
    <View style={styles.resultCard}>
      <View style={styles.resultHeader}>
        <Text style={styles.breachName}>{item.breachName}</Text>
        <Text style={styles.matchedField}>Match: {item.matchedField}</Text>
      </View>
      
      {item.breachDescription && (
        <Text style={styles.breachDescription}>{item.breachDescription}</Text>
      )}
      
      <View style={styles.contentContainer}>
        <Text style={styles.contentLabel}>Breach Data:</Text>
        <ScrollView style={styles.contentScroll} nestedScrollEnabled>
          <Text style={styles.contentText}>{item.content}</Text>
        </ScrollView>
      </View>
      
      <View style={styles.dataTypes}>
        {item.dataTypes.map((dataType, index) => (
          <Text key={index} style={styles.dataTypeTag}>
            {dataType}
          </Text>
        ))}
      </View>
    </View>
  );

  const renderHistoryItem = ({ item }: { item: Search }) => (
    <TouchableOpacity
      style={styles.historyItem}
      onPress={() => loadHistorySearch(item)}
    >
      <View style={styles.historyHeader}>
        <Text style={styles.historyQuery}>{item.query}</Text>
        <Text style={styles.historyDate}>
          {new Date(item.timestamp).toLocaleDateString()}
        </Text>
      </View>
      <Text style={styles.historyResults}>{item.resultCount} results</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🔍 Majic Breaches</Text>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'search' && styles.activeTab]}
          onPress={() => setActiveTab('search')}
        >
          <Text style={[styles.tabText, activeTab === 'search' && styles.activeTabText]}>
            Search
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'history' && styles.activeTab]}
          onPress={() => setActiveTab('history')}
        >
          <Text style={[styles.tabText, activeTab === 'history' && styles.activeTabText]}>
            History
          </Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'search' ? (
        <ScrollView style={styles.content}>
          {/* Search Form */}
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Enter email, username, password, phone, IP..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              editable={!isSearching}
              multiline={false}
            />
            
            <TouchableOpacity
              style={[styles.searchButton, isSearching && styles.searchButtonDisabled]}
              onPress={handleSearch}
              disabled={isSearching || !searchQuery.trim()}
            >
              {isSearching ? (
                <ActivityIndicator color="#ffffff" />
              ) : (
                <Text style={styles.searchButtonText}>Search Breaches</Text>
              )}
            </TouchableOpacity>
          </View>

          {/* Current Search Info */}
          {currentSearch && (
            <View style={styles.searchInfo}>
              <Text style={styles.searchInfoTitle}>
                Results for "{currentSearch.query}"
              </Text>
              <Text style={styles.searchInfoCount}>
                {searchResults.length} results found
              </Text>
            </View>
          )}

          {/* Search Results */}
          {searchResults.length > 0 && (
            <FlatList
              data={searchResults}
              renderItem={renderSearchResult}
              keyExtractor={(item) => item._id}
              style={styles.resultsList}
              nestedScrollEnabled
            />
          )}

          {/* No Results */}
          {currentSearch && searchResults.length === 0 && !isSearching && (
            <View style={styles.noResults}>
              <Text style={styles.noResultsText}>
                No results found for "{currentSearch.query}"
              </Text>
            </View>
          )}
        </ScrollView>
      ) : (
        <View style={styles.content}>
          {/* Search History */}
          {searchHistory.length > 0 ? (
            <FlatList
              data={searchHistory}
              renderItem={renderHistoryItem}
              keyExtractor={(item) => item._id}
              style={styles.historyList}
            />
          ) : (
            <View style={styles.noHistory}>
              <Text style={styles.noHistoryText}>No search history yet</Text>
            </View>
          )}
        </View>
      )}

      {/* Disclaimer */}
      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          ⚠️ For educational and security research purposes only
        </Text>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2563eb',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#2563eb',
  },
  tabText: {
    fontSize: 16,
    color: '#6b7280',
  },
  activeTabText: {
    color: '#2563eb',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  searchContainer: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  searchInput: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 12,
    backgroundColor: '#ffffff',
  },
  searchButton: {
    backgroundColor: '#2563eb',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  searchButtonDisabled: {
    backgroundColor: '#9ca3af',
  },
  searchButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  searchInfo: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
    elevation: 2,
  },
  searchInfoTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  searchInfoCount: {
    fontSize: 14,
    color: '#6b7280',
  },
  resultsList: {
    flex: 1,
  },
  resultCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    elevation: 2,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  breachName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2563eb',
    flex: 1,
  },
  matchedField: {
    fontSize: 12,
    color: '#059669',
    backgroundColor: '#d1fae5',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  breachDescription: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 12,
  },
  contentContainer: {
    backgroundColor: '#f9fafb',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  contentLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  contentScroll: {
    maxHeight: 150,
  },
  contentText: {
    fontSize: 12,
    color: '#1f2937',
    fontFamily: 'monospace',
    lineHeight: 16,
  },
  dataTypes: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dataTypeTag: {
    fontSize: 12,
    color: '#374151',
    backgroundColor: '#e5e7eb',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  noResults: {
    backgroundColor: '#ffffff',
    padding: 32,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 2,
  },
  noResultsText: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
  },
  historyList: {
    flex: 1,
  },
  historyItem: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    elevation: 2,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  historyQuery: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    flex: 1,
  },
  historyDate: {
    fontSize: 12,
    color: '#6b7280',
  },
  historyResults: {
    fontSize: 14,
    color: '#059669',
  },
  noHistory: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noHistoryText: {
    fontSize: 16,
    color: '#6b7280',
  },
  disclaimer: {
    backgroundColor: '#fef3c7',
    padding: 12,
    alignItems: 'center',
  },
  disclaimerText: {
    fontSize: 12,
    color: '#92400e',
    textAlign: 'center',
  },
});

export default App;
